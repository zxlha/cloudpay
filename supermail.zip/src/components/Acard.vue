<!--
 * @Author: your name
 * @Date: 2019-11-06 21:32:25
 * @LastEditTime: 2019-11-11 14:12:51
 * @LastEditors: 范钊
 * @Description: In User Settings Edit
 * @FilePath: \xinyiyuntan_f:\Vue\project_one\src\components\Search.vue
 -->
<template>
<div class="card">
    <img class="kamuxing" src="../assets/img/card2.png" alt="kamuxing">
</div>     
</template>

<script>
export default {
    name:"Acard",
    data(){
        return{
        } 
    },   
}
</script>

<style>
   .card{
       width: 100%;
       height: 2rem;
       padding-top:0.1rem;
   }
   .kamuxing{
       width: 95%;
       height: 2rem;
       margin:0 2.5%;
   }
   
</style>