<!--
 * @Author: your name
 * @Date: 2019-11-08 17:44:19
 * @LastEditTime: 2019-11-11 15:55:04
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \第三阶段d:\wordspace\myfile\src\components\arrow.vue
 -->
<template>
  <div class="arrow">
      <!--左箭头-->
      <img src="../../assets/img/sy_sdk_left.png">
  </div>
</template>

<script>
export default {
    name:'Arrow',
    data(){
        return{
            
        }
    },
    methods:{
        arrow(){
            
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    .arrow{
        width: 10%;
        height: .25rem;
    }
    img{
        width: .25rem;
        height: .25rem;
    }
</style>
