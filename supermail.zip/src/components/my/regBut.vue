<!--
 * @Author: your name
 * @Date: 2019-11-08 17:44:19
 * @LastEditTime: 2019-11-09 19:44:16
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \第三阶段d:\wordspace\myfile\src\components\arrow.vue
 -->
<template>
    <div class="regBut">
        注册
    </div>
</template>

<script>
export default {
    name:'regBut',
    data(){
        return{
            
        }
    },
    methods:{
        regBut(){
            
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.regBut{
    width: 1.2rem;
    height: .3rem;
    border-radius: 10px;
    background: red;
    margin: .8rem auto 0 auto;
    text-align: center;
    line-height: .3rem;
    font-size: .14rem;
    color: white;
}
</style>
