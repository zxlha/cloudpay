<!--
 * @Author: your name
 * @Date: 2019-11-08 17:44:19
 * @LastEditTime: 2019-11-15 17:56:53
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \第三阶段d:\wordspace\myfile\src\components\arrow.vue
 -->
<template>
  <div class="phoneNum-inp">
   <p class="loginBut">确认</p>
  </div>
</template>

<script>
export default {
  name: "phoneNum",
  data() {
    return {
       
    };
  },
  methods: {}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.loginBut{
    width: 1.2rem;
    height: .4rem;
    border-radius: 10px;
    background: red;
    margin: .3rem auto 0 auto;
    text-align: center;
    line-height: .4rem;
    font-size: .16rem;
    color: white;
}

</style>
