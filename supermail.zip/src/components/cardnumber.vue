<!--
 * @Author: your name
 * @Date: 2019-11-06 21:32:25
 * @LastEditTime: 2019-11-15 14:59:16
 * @LastEditors: 范钊
 * @Description: In User Settings Edit
 * @FilePath: \xinyiyuntan_f:\Vue\project_one\src\components\Search.vue
 -->
<template>
<div class="cardnumberbox">
   <p><b>银行卡</b> 共{{counts.count}}张</p>
</div>     
</template>

<script>
export default {
    name:"cardnumber",
    data(){
        return{
          counts:""
        } 
    },
    created(){
        fetch("/api/cardselectcount")
        .then(res=>{
            return res.json();
        })
        .then(data=>{
            this.counts=data[0];
        })
        .catch(err=>{
            console.log(err)
        })
    }
    
}
</script>

<style>
    .cardnumberbox{
        width: 100%;
        height: 0.2rem;
        padding:0.1rem;
    }
    p{
        font-size:0.16rem;
        color:gray;
    }
</style>