<!--
 * @Author: your name
 * @Date: 2019-11-04 17:31:06
 * @LastEditTime: 2019-11-12 21:22:47
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \第三阶段d:\wordspace\myfile\src\App.vue
 -->
<template>
  <div id="app">
     <h2>贾平</h2>
  </div>
</template>

<script>
  export default {
    name:'register',
    data(){
        return{
        }
    },
    components:{
    }
  }
</script>

<style>
</style>
