<!--
 * @Author: your name
 * @Date: 2019-11-08 20:29:24
 * @LastEditTime: 2019-11-12 21:20:58
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \vue\tabbar\src\components\tabbar\tabBar.vue
 -->
<template>
<div class="rich">
  <h2>范钊</h2>
</div>
</template>

<script>
export default {
  name: 'rich',
  props:['id'],
  components:{
    
  },
  mounted(){
    // console.log(this.id)
  }
}
</script>

<style>
</style>