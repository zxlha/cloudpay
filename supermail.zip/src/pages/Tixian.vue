<!--
 * @Author: 范钊
 * @Date: 2019-11-06 21:31:30
 * @LastEditors: 范钊
 * @LastEditTime: 2019-11-15 18:03:07
 * @Description: "转账"
 -->
<template>
<div class="box">
  <Aback>
    <b class="wenzi">提现</b>
  </Aback>
  <Rfangshi>
      <i class="Rtext">到账银行卡</i>
  </Rfangshi>
</div>
</template>

<script>
import Aback from "../components/Aback"
import Rfangshi from "../components/Rfangshi"
import Ranniu from "../components/Ranniu"

export default {  
    name:"Tixian",
    data(){
        return{
           
        }
    },
    components:{
      Aback,Rfangshi,Ranniu
    }
}
</script>

<style scoped>
 .wenzi{
   margin-left:1.3rem;
   display: inline-block;
   font-size: 0.2rem;
 }
 .Rtext{
        font-style: normal;
    }
</style>