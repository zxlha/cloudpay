<!--
 * @Author: 范钊
 * @Date: 2019-11-06 21:31:30
 * @LastEditors: 范钊
 * @LastEditTime: 2019-11-15 17:17:50
 * @Description: "交易记录"
 -->
<template>
    <div class="Rechargebox">
        <Aback>
            <b class="wenzi">充值</b>
        </Aback>
        <Jyheader></Jyheader>
        <Rfangshi>
            <i class="Rtext">充值方式</i>
        </Rfangshi>
    </div>
</template>

<script>
import Aback from "../components/Aback"
import Rfangshi from "../components/Rfangshi"
import Ranniu from "../components/Ranniu"
export default {  
    name:"Recharge",
    data(){
        return{
           
        }
    },
    components:{
     Aback,Rfangshi,Ranniu
    }
}
</script>

<style scoped>
    .wenzi{
        display: inline-block;
        font-size: 0.2rem;
        margin-left: 1.4rem;  
    }
    .Rtext{
        font-style: normal;
    }
</style>